<?php $__env->startSection('content'); ?>
<h3><i class="fa fa-angle-right"></i>Enroll New Prisoner</h3>

    <!-- INLINE FORM ELELEMNTS -->
    <div class="row">

        <div class="col-lg-12">
            <div class="panel panel-danger">
                <div class="panel-heading">Fill in Prisoner Details</div>
                <div class="panel-body">
                <form class="form-horizontal" role="form" method="POST" enctype="multipart/form-data"
                          action="<?php echo e(url('')); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group">
                            <label class="col-md-2 control-label">Prisoner First Name</label>
                            <div class="col-md-2">
                                <input type="text" class="form-control" name="first_name" value="<?php echo e(old('first_name')); ?>">
                            </div>

                            <label class="col-md-2 control-label">Prisoner Middle Name</label>
                            <div class="col-md-2">
                                <input type="text" class="form-control" name="middle_name" value="<?php echo e(old('middle_name')); ?>">
                            </div>
                            <label class="col-md-2 control-label">Prisoner Last Name</label>
                            <div class="col-md-2">
                                <input type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-2 control-label">Home County</label>
                            <div class="col-md-2">
                                <input type="text" class="form-control" name="middle_name" value="<?php echo e(old('middle_name')); ?>">
                            </div>
                            <label class="col-md-2 control-label">Home Location</label>
                            <div class="col-md-2">
                                <input type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Prisoner Last Name</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Prisoner Email</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Prisoner Mobile Number</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="mobile" value="<?php echo e(old('mobile')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Date of Imprisonment</label>
                            <div class="col-md-6">
                                <input type="date" class="form-control" placeholder="Y-M-D" name="adm_date" value="<?php echo e(old('adm_date')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Crime</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="course" value="<?php echo e(old('course')); ?>">
                            </div>
                        </div>



                        <div class="form-group">
                            <label class="col-md-4 control-label">Gender</label>
                            <div class="col-md-6">
                                <select name="gender" class="form-control">
                                    <option>Male</option>
                                    <option>Female</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Date of Birth</label>
                            <div class="col-md-6">
                                <input type="date" class="form-control" placeholder="Y-M-D" name="dob" value="<?php echo e(old('dob')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-md-4 control-label">Upload Prisoner Photo.</label>
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="profile_pix" placeholder="Upload Image"/>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">Submit Entry</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div><!-- /col-lg-12 -->

        <div class="col-lg-6">

        </div>

    </div><!-- /row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('prisonhome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>