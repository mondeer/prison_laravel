<!-- top navigation -->
<div class="top_nav imonda">
    <div class="nav_menu imonda">
        <nav class="fh5co-nav-style-1 imonda " role="navigation" data-offcanvass-position="fh5co-offcanvass-left">
              <div class="nav toggle">
                  <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <div class="col-lg-5 text-center fh5co-link-wrap">

                <ul data-offcanvass="yes">
                  <li><a href="" class="call-to-action">View Prisoners</a></li>
                  <li><a href="" class="call-to-action">Enroll New Prisoner</a></li>
                  <li><a href="" class="call-to-action">Release A Prisoner</a></li>
                </ul>
              </div>
              <div class="col-lg-6 imon">

                <ul class="nav navbar-nav navbar-right">

                  <li>
                      <!-- <div class="pull-right"> -->
                        <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" >

                          <h3 class="imondwhite">
                            Getty<span class=" fa fa-angle-down"></span>
                          </h3>

                        </a>
                        <ul class="dropdown-menu dropdown-usermenu">
                            <li><a href="javascript:;">Help</a></li>
                            <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                        </ul>
                    </li>
                </ul>

              </div>
            </nav>

        </div>

</div>
<!-- /top navigation -->
