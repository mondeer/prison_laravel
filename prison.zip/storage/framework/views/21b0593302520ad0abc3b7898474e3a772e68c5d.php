<?php $__env->startSection('main_container'); ?>
    <div class="right_col" role="main">
        <?php echo $__env->yieldContent('content'); ?>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>